let font;  //載入字型文字
let points = [];  //轉成點狀文字
let r=15  //增加上下幅度
let angle=0
// ==================================================
function preload(){  //在執行setup()前，必須先做此函數執行，主要先載入字型
    //為載入在fonts資料夾內的Zeyada-Regular.ttf字型
    font = loadFont("fonts/Oswald-VariableFont_wght.ttf") 
}
//===================================================


function setup() {
  //畫布的寬高與背景顏色
  createCanvas(windowWidth, windowHeight,WEBGL);
  background("#fefae0")
  points = font.textToPoints("TKU", -300, 80, 200, {
    sampleFactor:0.07 //數字越小，點數越大
  }); //轉成文字圖檔，放在(0, 0)位置，圖形大小為200，sampleFactor為點數距離大小
  //for (let i=0; i<points.length; i++) { 
   // text(str(i),points[i].x,points[i].y)
   // ellipse(points(i).x,points[i].y,10)
   //rect(points[i].x,points[i].y,10)
 // } 
angleMode(DEGREES); //宣告角度使用0~360
translate(width/2,height/2) //把(0,0座標點，移到視窗的中間)
}

//===================================================

function draw() { //畫圖
   
  background("#fefae0");

 // translate(width/2,height/2) //把(0,0座標點，移到視窗的中間) 
 // translate(mouseX,mouseY) //把(0,0)座標點，移到滑鼠座標上
  rotateX((angle)%360) //以(0,0)中心點旋轉角度，角度的值為0~360
  for (let i=0; i<points.length-1; i++) { 
  //  text(str(i),points[i].x,points[i].y)
  fill("#a2d2ff") //圓的充滿顏色
  noStroke() //圓不要框線
    ellipse(points[i].x+r*sin(angle+i*25),points[i].y,10)
    strokeWeight(3) //畫線的粗細
    stroke("#ffb3c6") //畫線的顏色
    line(points[i].x+r*sin(angle+i*25),points[i].y,points[i+1].x,points[i+1].y) //兩點間畫一條線
 }
angle= angle + 10 //每次畫圖一次就要調整角度+10
}
